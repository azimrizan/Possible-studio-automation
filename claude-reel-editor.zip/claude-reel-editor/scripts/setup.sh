#!/usr/bin/env bash
# One-time setup inside Claude's sandbox. Safe to re-run. Usage: bash setup.sh [lang]
#   lang = en (default) or any other language code (ml, hi, ta, ar, ...) -> downloads the multilingual model
# Writes ~/edit/env.json with the paths every other script uses.
set -u
LANG_CODE="${1:-en}"
W=~/edit; mkdir -p $W/models $W/fonts; cd $W
log(){ echo "[setup] $*"; }
PIP="pip install -q --break-system-packages"
$PIP sherpa-onnx soundfile opencv-python-headless scipy numpy onnxruntime playwright imageio-ffmpeg >/dev/null 2>&1 || $PIP sherpa-onnx soundfile opencv-python-headless scipy numpy onnxruntime playwright imageio-ffmpeg
# ffmpeg: system first, then the static binary that ships inside the imageio-ffmpeg wheel
FF=$(command -v ffmpeg || python3 -c "import imageio_ffmpeg as f;print(f.get_ffmpeg_exe())")
log "ffmpeg: $FF"
# headless browser for graphics: preinstalled Playwright Chromium, else npm @sparticuz/chromium
CHROME=""; CHROME_ARGS="[]"
if python3 - <<'PY' 2>/dev/null
from playwright.sync_api import sync_playwright
with sync_playwright() as p: p.chromium.launch().close()
PY
then CHROME="playwright"
else
  mkdir -p $W/chromium && (cd $W/chromium && npm init -y >/dev/null 2>&1 && npm i --silent @sparticuz/chromium@131 >/dev/null 2>&1)
  CHROME=$(cd $W/chromium && node -e "require('@sparticuz/chromium').executablePath().then(p=>console.log(p))")
  CHROME_ARGS=$(cd $W/chromium && node -e "console.log(JSON.stringify(require('@sparticuz/chromium').args))")
fi
log "browser: $CHROME"
# fonts from npm (Google Fonts is usually blocked in the sandbox)
cd $W/fonts && for p in @fontsource/inter-tight @fontsource/instrument-serif @fontsource/jetbrains-mono @fontsource/anek-malayalam @fontsource/noto-sans-devanagari @fontsource/noto-sans-tamil @fontsource/noto-sans-arabic; do
  n=$(echo $p | sed 's#@fontsource/##'); [ -d $n ] || { npm pack $p --silent >/dev/null 2>&1 && f=$(ls fontsource-$n-*.tgz 2>/dev/null | head -1) && mkdir -p $n && tar xzf $f -C $n --strip-components=1 && rm -f $f; }; done
cd $W
# speech models (free, from the sherpa-onnx GitHub releases)
B=https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models
if [ "$LANG_CODE" = "en" ]; then
  [ -d models/parakeet ] || { curl -fsSL $B/sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8.tar.bz2 | tar xj -C models && mv models/sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8 models/parakeet; }
  ASR=$( [ -f models/parakeet/tokens.txt ] && echo parakeet || echo none )
else
  [ -d models/omni ] || { curl -fsSL $B/sherpa-onnx-omnilingual-asr-1600-languages-1B-ctc-int8-2025-11-12.tar.bz2 | tar xj -C models && mv models/sherpa-onnx-omnilingual-asr-1600-languages-1B-ctc-int8-2025-11-12 models/omni; }
  ASR=$( [ -f models/omni/tokens.txt ] && echo omni || echo none )
fi
log "speech model: $ASR"
# person cut-out model for text-behind-head (optional)
mkdir -p models/seg; [ -f models/seg/u2net_human_seg.onnx ] || curl -fsSL -o models/seg/u2net_human_seg.onnx https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net_human_seg.onnx || rm -f models/seg/u2net_human_seg.onnx
SEG=$( [ -s models/seg/u2net_human_seg.onnx ] && echo yes || echo no )
log "cut-out model: $SEG"
python3 - "$FF" "$CHROME" "$CHROME_ARGS" "$ASR" "$SEG" <<'PY'
import json,sys,os
ff,ch,args,asr,seg=sys.argv[1:6]
json.dump({"ffmpeg":ff,"chrome":ch,"chrome_args":json.loads(args),"asr":asr,"seg":seg=="yes","home":os.path.expanduser("~/edit")},open(os.path.expanduser("~/edit/env.json"),"w"),indent=1)
PY
echo "[setup] done -> ~/edit/env.json"; cat ~/edit/env.json
