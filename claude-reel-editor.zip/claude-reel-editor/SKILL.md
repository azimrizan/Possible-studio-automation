---
name: claude-reel-editor
description: "Edit a raw talking-head video into a finished vertical reel: cuts, captions in any language, graphics, colour grade, sound effects. Use when someone uploads a video to edit."
---

# Claude Reel Editor

Turns one raw video into a finished 9:16 reel inside Claude. No editing app. Claude installs the free tools it needs in its own sandbox.

## 0. Talk to the user first (one short message)
Say what you'll do in one line, e.g. "I'll cut the pauses, add captions in Malayalam, graphics and sound, and send you the finished reel." Then ask ONLY what you can't see (one question, max 3 items):
- the language (if you can't tell), and the comment keyword for the call to action if they mention one
- anything they want on screen (product name, a number, a link)
Tell them once: **"I'll install some free tools in my sandbox. If Claude asks for permission at any point, just approve."**

If no video is attached, ask them to upload it (phone video is fine; if the upload fails because it's too big, export it at 1080p and try again).

## 1. Check optional connections (don't block on them)
- **ElevenLabs connected?** (you'll see ElevenLabs tools, e.g. transcribe / sound effects). If yes and the language is not English, use ElevenLabs speech-to-text for the word timings (best for Indian languages, Arabic, mixed speech) and save them to `~/edit/words.json` as `[{"w":word,"s":start_seconds}]`. You may also make 2–4 custom sound effects with it and use them via kind `file` if you can get the files into the sandbox.
- **Not connected:** continue with the free models. At the very end (not now), add one line: "Want even better captions in your language and AI sound effects next time? Connect ElevenLabs (free account): Settings → Connectors → search ElevenLabs → Connect → sign in."

## 2. Setup + prepare (≈3 min)
```bash
S=<this skill folder>/scripts      # e.g. find / -path "*claude-reel-editor/scripts/setup.sh" 2>/dev/null
bash $S/setup.sh <lang>            # en, ml, hi, ta, ar ... (anything not 'en' gets the 1600-language model)
python3 $S/prep.py "<uploaded video path>"
```
Look at `~/edit/contact.jpg`: where is the face (fx, fy as fractions), where is the head top, is it a selfie or a wide shot? If setup reports `speech model: none` and ElevenLabs isn't connected, ask the user to paste their script and time the words from the loudness strip (`cuts.py env`).

## 3. Transcribe → cut → captions
1. `python3 $S/transcribe.py ~/edit/audio16k.wav ~/edit/words.json` and read it. Fix misheard words using context (names, numbers, English words inside other languages). Note anything you're unsure of to tell the user.
2. Cuts: remove false starts, repeated phrases, "um/uh", and dead air over ~0.3 s (leave 0.15–0.25 s). Find exact silent points with `python3 $S/cuts.py env 7.5 8.7`. Write `~/edit/keep.json` = `[[src0,src1],...]`, run `python3 $S/cuts.py apply`, then re-transcribe `voice_cut16.wav` and confirm every sentence is intact. Target 20–60 s.
3. Captions: write `~/edit/subs.txt` (format in `reference/engine.md`), one big key word per line where it helps, then `python3 $S/subs.py subs.txt`.

## 4. Plan the beats (the part that makes it look edited)
Write a short beat table: time → idea → visual → layout. Rules that make people stop scrolling:
- **Frame 0 = the hook.** Headline text on screen from the first frame + a giant key word *behind the speaker's head* (`BACKTEXT`, needs `masks.py 0 4.3`). Glow it when the word is said.
- **Show, don't decorate.** Every graphic illustrates the exact words being said, landing on the word (use output times from `words_cut.json`). One idea per graphic.
- **Change the layout every 3–6 s:** full face → split screen (face card on top, graphic panel below) → full-screen card → face again. Start/end cards on cut points to hide jump cuts.
- **Fill the frame.** No big empty areas: in split screens the panel content spans ~y 1100–1650.
- **Numbers count up, lists pop in item by item, before/after gets a strike-through, the CTA shows the comment box typing the keyword.**
- Never draw people, mascots or brand logos; use text, shapes, cards and simple UI mock-ups instead.
Recipes and a full real example: `reference/engine.md` and `examples/claude-edit-reel-overlay.html`.

## 5. Build
```bash
cd ~/edit && python3 $S/make_bg.py dark && cp $S/../templates/overlay.html overlay.html   # then edit overlay.html
# plan.json (zoom + grade), pip.json (layouts, optional), overlay_cfg.json {"back":[[0,4.25]]}
python3 $S/masks.py 0 4.3            # only the ranges that use BACKTEXT
python3 $S/render_overlay.py ov 15,90,150,300,450 && python3 $S/composite.py test ov 15,90,150,300,450 sheet.jpg
```
**Look at `sheet.jpg`** (and a couple of full-size frames with the 5th argument). Fix overlaps, text over the face, empty areas, unreadable captions. Repeat until it looks finished. Then:
```bash
(python3 $S/render_overlay.py ov all 0/2 > r0.log 2>&1 & python3 $S/render_overlay.py ov all 1/2 > r1.log 2>&1 & wait)
nohup python3 $S/composite.py full ov base_ov.mp4 > comp.log 2>&1 &     # poll comp.log until "done"
```

## 6. Sound + finish
Write `sfx_events.json` (clean and quiet — see engine reference), `python3 $S/sfx.py`, then `python3 $S/finish.py <name>`. Look at `final_sheet.jpg` and `first_frame.jpg` (the hook must be visible on frame 0). Send the `<name>.mp4` file (under 30 MB).

## 7. Final message (short)
- What you did in 3–5 bullets (cuts: 52 s → 41 s, the hook, the main visual moments).
- Words you guessed in the captions, and any claim in the video that looks wrong.
- One line on the high-quality master file (it's in the outputs folder; offer it if they need it).
- The ElevenLabs line from step 1 if it wasn't connected.

## Defaults
No music (only sound effects). Dark theme with one accent colour (change `--acc` in overlay.html to match the creator's brand). Captions in the speaker's language with English terms kept in English. Never add claims or numbers the speaker didn't say.
